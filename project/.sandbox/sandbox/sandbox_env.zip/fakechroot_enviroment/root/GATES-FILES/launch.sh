#!/bin/bash

chmod +x /GATES-FILES/game
/GATES-FILES/game $@
